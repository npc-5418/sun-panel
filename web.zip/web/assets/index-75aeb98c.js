import{be as o}from"./index-3f268199.js";function n(r){return o({url:"/login",data:r})}function u(){return o({url:"/logout"})}export{u as a,n as l};
